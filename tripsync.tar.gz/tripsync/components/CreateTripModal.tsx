'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase'
import { X, Plane } from 'lucide-react'

export default function CreateTripModal({ userId, onClose, onCreated }: {
  userId: string; onClose: () => void; onCreated: (id: string) => void
}) {
  const [name, setName] = useState('')
  const [destination, setDestination] = useState('')
  const [dateStart, setDateStart] = useState('')
  const [dateEnd, setDateEnd] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const supabase = createClient()

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true); setError('')
    const { data, error } = await supabase.from('trips').insert({
      name,
      host_id: userId,
      destination: destination || null,
      date_start: dateStart || null,
      date_end: dateEnd || null,
    }).select().single()
    if (error) { setError(error.message); setLoading(false); return }
    onCreated(data.id)
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel sm:max-w-md p-6 sm:p-8" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="font-display text-2xl font-700">New trip</h2>
            <p className="text-sm text-[#6b6760] mt-0.5">Fill in the basics — you can add more later</p>
          </div>
          <button onClick={onClose} className="btn-ghost p-2"><X size={18} /></button>
        </div>

        {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl p-3 mb-4">{error}</div>}

        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="label">Trip name *</label>
            <input className="input" placeholder='e.g., "Spain Trip 2025"' value={name} onChange={e => setName(e.target.value)} required />
          </div>
          <div>
            <label className="label">Destination (optional)</label>
            <input className="input" placeholder="Still deciding? Leave blank" value={destination} onChange={e => setDestination(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Start date</label>
              <input className="input" type="date" value={dateStart} onChange={e => setDateStart(e.target.value)} />
            </div>
            <div>
              <label className="label">End date</label>
              <input className="input" type="date" value={dateEnd} onChange={e => setDateEnd(e.target.value)} />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 flex items-center justify-center gap-2">
              {loading ? 'Creating...' : <><Plane size={15} /> Create trip</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
