'use client'
import { useState, useEffect } from 'react'
import { Plus, ArrowRight, DollarSign, X, Check, TrendingUp, TrendingDown } from 'lucide-react'

function getAvatarColor(name: string) {
  const colors = ['bg-[#e8572a]','bg-[#0f7b6c]','bg-[#c9973a]','bg-purple-500','bg-pink-500','bg-blue-500']
  let hash = 0; for (const c of name) hash += c.charCodeAt(0)
  return colors[hash % colors.length]
}

const CATEGORIES = ['Accommodation','Food & Drink','Transport','Activities','Shopping','Other']

export default function ExpensesTab({ trip, user, profile, tripId, supabase }: any) {
  const [expenses, setExpenses] = useState<any[]>([])
  const [members, setMembers] = useState<any[]>([])
  const [showAdd, setShowAdd] = useState(false)

  useEffect(() => {
    const load = async () => {
      const [{ data: exp }, { data: mem }] = await Promise.all([
        supabase.from('expenses').select('*').eq('trip_id', tripId).order('created_at', { ascending: false }),
        supabase.from('trip_members').select('*, profiles(id, name, email)').eq('trip_id', tripId)
      ])
      setExpenses(exp || [])
      setMembers(mem || [])
    }
    load()
    const sub = supabase.channel(`exp:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expenses', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId])

  // Calculate balances
  const calcBalances = () => {
    const bal: Record<string, { name: string; amount: number }> = {}
    members.forEach(m => { bal[m.user_id] = { name: m.profiles?.name || 'Unknown', amount: 0 } })
    expenses.forEach(exp => {
      const splitAmong: string[] = exp.split_among || []
      if (splitAmong.length === 0) return
      const perPerson = exp.amount / splitAmong.length
      if (bal[exp.paid_by]) bal[exp.paid_by].amount += exp.amount
      splitAmong.forEach(uid => { if (bal[uid]) bal[uid].amount -= perPerson })
    })
    return bal
  }

  // Minimize transactions
  const getSettlements = () => {
    const bal = calcBalances()
    const creditors = Object.entries(bal).filter(([,v]) => v.amount > 0.01).map(([id,v]) => ({ id, ...v })).sort((a,b) => b.amount - a.amount)
    const debtors = Object.entries(bal).filter(([,v]) => v.amount < -0.01).map(([id,v]) => ({ id, name: v.name, amount: -v.amount })).sort((a,b) => b.amount - a.amount)
    const txns: { from: string; to: string; amount: number }[] = []
    let i = 0, j = 0
    const c = creditors.map(x => ({...x})), d = debtors.map(x => ({...x}))
    while (i < c.length && j < d.length) {
      const amt = Math.min(c[i].amount, d[j].amount)
      txns.push({ from: d[j].name, to: c[i].name, amount: amt })
      c[i].amount -= amt; d[j].amount -= amt
      if (c[i].amount < 0.01) i++
      if (d[j].amount < 0.01) j++
    }
    return txns
  }

  const balances = calcBalances()
  const settlements = getSettlements()
  const total = expenses.reduce((s, e) => s + Number(e.amount), 0)
  const myBalance = balances[user.id]?.amount || 0

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-700">Expenses</h2>
          <p className="text-sm text-[#6b6760]">Track and split group spending</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary flex items-center gap-2 text-sm"><Plus size={15} />Add</button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="card p-4 text-center">
          <p className="text-xs text-[#6b6760] mb-1">Total spent</p>
          <p className="font-display text-xl font-700">${total.toFixed(0)}</p>
        </div>
        <div className={`card p-4 text-center ${myBalance > 0 ? 'bg-[#e8f5f2]' : myBalance < 0 ? 'bg-red-50' : ''}`}>
          <p className="text-xs text-[#6b6760] mb-1">You're owed</p>
          <p className={`font-display text-xl font-700 ${myBalance > 0 ? 'text-[#0f7b6c]' : myBalance < 0 ? 'text-red-600' : ''}`}>
            {myBalance >= 0 ? '+' : '-'}${Math.abs(myBalance).toFixed(0)}
          </p>
        </div>
        <div className="card p-4 text-center">
          <p className="text-xs text-[#6b6760] mb-1">Expenses</p>
          <p className="font-display text-xl font-700">{expenses.length}</p>
        </div>
      </div>

      {/* Settlements */}
      {settlements.length > 0 && (
        <div className="card p-4">
          <p className="font-semibold text-sm text-[#1a1814] mb-3">How to settle up</p>
          <div className="space-y-2">
            {settlements.map((t, i) => (
              <div key={i} className="flex items-center gap-2 text-sm">
                <span className="font-semibold text-[#1a1814]">{t.from}</span>
                <ArrowRight size={14} className="text-[#e8572a] shrink-0" />
                <span className="font-semibold text-[#1a1814]">{t.to}</span>
                <span className="ml-auto font-bold text-[#0f7b6c]">${t.amount.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Individual balances */}
      {Object.keys(balances).length > 0 && (
        <div className="card divide-y divide-stone-100">
          {Object.entries(balances).map(([uid, { name, amount }]) => (
            <div key={uid} className="flex items-center gap-3 px-4 py-3">
              <div className={`avatar w-8 h-8 text-xs ${getAvatarColor(name)}`}>{name[0]?.toUpperCase()}</div>
              <span className="flex-1 text-sm font-medium">{name}{uid === user.id ? ' (you)' : ''}</span>
              <div className={`flex items-center gap-1 text-sm font-bold ${amount > 0.01 ? 'text-[#0f7b6c]' : amount < -0.01 ? 'text-red-500' : 'text-[#6b6760]'}`}>
                {amount > 0.01 ? <TrendingUp size={13} /> : amount < -0.01 ? <TrendingDown size={13} /> : null}
                {amount > 0.01 ? '+' : ''}{amount.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Expense list */}
      <div>
        <p className="font-semibold text-sm text-[#1a1814] mb-2">All expenses</p>
        {expenses.length === 0 ? (
          <div className="card p-10 text-center">
            <p className="text-3xl mb-2">💸</p>
            <p className="font-display text-lg font-700 mb-1">No expenses yet</p>
            <p className="text-sm text-[#6b6760] mb-4">Add the first one to start tracking</p>
            <button onClick={() => setShowAdd(true)} className="btn-primary text-sm">Add expense</button>
          </div>
        ) : (
          <div className="card divide-y divide-stone-100">
            {expenses.map(exp => {
              const perPerson = exp.amount / (exp.split_among?.length || 1)
              return (
                <div key={exp.id} className="flex items-center gap-3 px-4 py-3">
                  <div className="w-9 h-9 rounded-xl bg-[#fdf6e8] flex items-center justify-center shrink-0">
                    <DollarSign size={14} className="text-[#c9973a]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-[#1a1814] truncate">{exp.title}</p>
                    <p className="text-xs text-[#6b6760]">Paid by {exp.paid_by_name} · ${perPerson.toFixed(2)}/person · {exp.split_among?.length || 1} people</p>
                  </div>
                  <p className="font-bold text-[#1a1814] shrink-0">${Number(exp.amount).toFixed(2)}</p>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {showAdd && <AddExpenseModal tripId={tripId} user={user} profile={profile} members={members} supabase={supabase} onClose={() => setShowAdd(false)} />}
    </div>
  )
}

function AddExpenseModal({ tripId, user, profile, members, supabase, onClose }: any) {
  const [form, setForm] = useState({ title: '', amount: '', category: '', paid_by: user.id, paid_by_name: profile?.name || '' })
  const [splitAmong, setSplitAmong] = useState<string[]>(members.map((m: any) => m.user_id))
  const [loading, setLoading] = useState(false)

  const toggleSplit = (uid: string) => {
    setSplitAmong(prev => prev.includes(uid) ? prev.filter(id => id !== uid) : [...prev, uid])
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (splitAmong.length === 0) return alert('Select at least one person to split with')
    setLoading(true)
    const paidByProfile = members.find((m: any) => m.user_id === form.paid_by)
    await supabase.from('expenses').insert({
      trip_id: tripId, title: form.title,
      amount: parseFloat(form.amount), category: form.category || null,
      paid_by: form.paid_by,
      paid_by_name: paidByProfile?.profiles?.name || profile?.name,
      split_among: splitAmong,
      date: new Date().toISOString().split('T')[0]
    })
    setLoading(false); onClose()
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel p-6 sm:p-8" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-700">Add expense</h2>
          <button onClick={onClose} className="btn-ghost p-2"><X size={16} /></button>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Description *</label><input className="input" placeholder="Airbnb deposit, dinner, etc." value={form.title} onChange={e => setForm({...form, title: e.target.value})} required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Amount ($) *</label><input className="input" type="number" step="0.01" min="0" placeholder="0.00" value={form.amount} onChange={e => setForm({...form, amount: e.target.value})} required /></div>
            <div>
              <label className="label">Category</label>
              <select className="input" value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                <option value="">Select...</option>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="label">Paid by</label>
            <select className="input" value={form.paid_by} onChange={e => setForm({...form, paid_by: e.target.value})}>
              {members.map((m: any) => <option key={m.user_id} value={m.user_id}>{m.profiles?.name}{m.user_id === user.id ? ' (you)' : ''}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Split among</label>
            <div className="flex flex-wrap gap-2">
              {members.map((m: any) => {
                const name = m.profiles?.name || 'Unknown'
                const isIn = splitAmong.includes(m.user_id)
                return (
                  <button key={m.user_id} type="button" onClick={() => toggleSplit(m.user_id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-semibold border transition-all ${isIn ? 'bg-[#0f7b6c] text-white border-[#0f7b6c]' : 'bg-white text-[#6b6760] border-stone-200 hover:bg-stone-50'}`}>
                    {isIn && <Check size={12} />}{name}
                  </button>
                )
              })}
            </div>
            {form.amount && splitAmong.length > 0 && (
              <p className="text-xs text-[#6b6760] mt-2">${(parseFloat(form.amount || '0') / splitAmong.length).toFixed(2)} per person</p>
            )}
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1">{loading ? 'Adding...' : 'Add expense'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
