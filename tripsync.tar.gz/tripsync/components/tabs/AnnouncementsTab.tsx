'use client'
import { useState, useEffect } from 'react'
import { Megaphone, Pin, Plus, X, Trash2 } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

function getAvatarColor(name: string) {
  const colors = ['bg-[#e8572a]','bg-[#0f7b6c]','bg-[#c9973a]','bg-purple-500','bg-pink-500','bg-blue-500']
  let hash = 0; for (const c of name) hash += c.charCodeAt(0)
  return colors[hash % colors.length]
}

export default function AnnouncementsTab({ trip, user, profile, tripId, canEdit, supabase }: any) {
  const [announcements, setAnnouncements] = useState<any[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [message, setMessage] = useState('')
  const [pinned, setPinned] = useState(false)
  const [posting, setPosting] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('announcements').select('*').eq('trip_id', tripId).order('pinned', { ascending: false }).order('created_at', { ascending: false })
      setAnnouncements(data || [])
    }
    load()
    const sub = supabase.channel(`ann:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId])

  const post = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return
    setPosting(true)
    await supabase.from('announcements').insert({
      trip_id: tripId, created_by: user.id,
      created_by_name: profile?.name || 'Host',
      message: message.trim(), pinned
    })
    setMessage(''); setPinned(false); setShowCreate(false); setPosting(false)
  }

  const togglePin = async (annId: string, isPinned: boolean) => {
    await supabase.from('announcements').update({ pinned: !isPinned }).eq('id', annId)
  }

  const deleteAnn = async (annId: string) => {
    if (!confirm('Delete this announcement?')) return
    await supabase.from('announcements').delete().eq('id', annId)
  }

  return (
    <div className="max-w-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-700">Updates</h2>
          <p className="text-sm text-[#6b6760]">Announcements from trip hosts</p>
        </div>
        {canEdit && (
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary flex items-center gap-2 text-sm">
            <Megaphone size={15} /> Post update
          </button>
        )}
      </div>

      {/* Compose box */}
      {showCreate && canEdit && (
        <div className="card p-5 fade-up">
          <form onSubmit={post} className="space-y-3">
            <div>
              <label className="label">Message</label>
              <textarea
                className="input min-h-[100px] resize-none"
                placeholder="Share an update with the group..."
                value={message}
                onChange={e => setMessage(e.target.value)}
                autoFocus
              />
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={pinned} onChange={e => setPinned(e.target.checked)} className="rounded" />
              <span className="text-sm text-[#1a1814]">Pin this announcement to the top</span>
            </label>
            <div className="flex gap-2">
              <button type="button" onClick={() => setShowCreate(false)} className="btn-secondary flex-1 py-2 text-sm">Cancel</button>
              <button type="submit" disabled={posting || !message.trim()} className="btn-primary flex-1 py-2 text-sm">{posting ? 'Posting...' : 'Post'}</button>
            </div>
          </form>
        </div>
      )}

      {announcements.length === 0 ? (
        <div className="card p-12 text-center">
          <Megaphone size={40} className="text-stone-300 mx-auto mb-3" />
          <h3 className="font-display text-lg font-700 mb-1">No updates yet</h3>
          <p className="text-sm text-[#6b6760]">
            {canEdit ? 'Post an update to keep the group informed' : 'Hosts will post trip updates here'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {announcements.map(ann => (
            <div key={ann.id} className={`card p-5 transition-all ${ann.pinned ? 'ring-2 ring-[#c9973a] bg-[#fdf6e8]/50' : ''}`}>
              <div className="flex items-start gap-3">
                <div className={`avatar w-9 h-9 text-sm shrink-0 ${getAvatarColor(ann.created_by_name || 'H')}`}>
                  {(ann.created_by_name || 'H')[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-semibold text-sm text-[#1a1814]">{ann.created_by_name}</span>
                    {ann.pinned && (
                      <span className="badge bg-[#fdf6e8] text-[#c9973a] flex items-center gap-1">
                        <Pin size={10} />Pinned
                      </span>
                    )}
                    <span className="text-xs text-[#6b6760]">
                      {formatDistanceToNow(new Date(ann.created_at), { addSuffix: true })}
                    </span>
                  </div>
                  <p className="text-sm text-[#1a1814] leading-relaxed whitespace-pre-wrap">{ann.message}</p>
                </div>
                {canEdit && (
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => togglePin(ann.id, ann.pinned)}
                      className={`p-1.5 rounded-lg transition-all ${ann.pinned ? 'text-[#c9973a] bg-[#fdf6e8]' : 'text-stone-400 hover:text-[#c9973a]'}`}>
                      <Pin size={13} />
                    </button>
                    <button onClick={() => deleteAnn(ann.id)} className="p-1.5 rounded-lg text-stone-400 hover:text-red-500 transition-all">
                      <Trash2 size={13} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
