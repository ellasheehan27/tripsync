'use client'
import { useState } from 'react'
import { MapPin, Calendar, Users, Crown, Edit2, Check, X } from 'lucide-react'

export default function OverviewTab({ trip, canEdit, supabase, onRefresh }: any) {
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({ name: trip.name, destination: trip.destination || '', date_start: trip.date_start || '', date_end: trip.date_end || '' })
  const [saving, setSaving] = useState(false)

  const save = async () => {
    setSaving(true)
    await supabase.from('trips').update(form).eq('id', trip.id)
    setSaving(false); setEditing(false); onRefresh()
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Trip info card */}
      <div className="card p-6">
        <div className="flex items-start justify-between mb-4">
          <h2 className="font-display text-2xl font-700">{trip.name}</h2>
          {canEdit && !editing && (
            <button onClick={() => setEditing(true)} className="btn-ghost p-2"><Edit2 size={15} /></button>
          )}
          {editing && (
            <div className="flex gap-2">
              <button onClick={save} disabled={saving} className="btn-teal p-2"><Check size={15} /></button>
              <button onClick={() => setEditing(false)} className="btn-secondary p-2"><X size={15} /></button>
            </div>
          )}
        </div>

        {editing ? (
          <div className="space-y-3">
            <div><label className="label">Trip name</label><input className="input" value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></div>
            <div><label className="label">Destination</label><input className="input" placeholder="Where are you going?" value={form.destination} onChange={e => setForm({...form, destination: e.target.value})} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Start date</label><input className="input" type="date" value={form.date_start} onChange={e => setForm({...form, date_start: e.target.value})} /></div>
              <div><label className="label">End date</label><input className="input" type="date" value={form.date_end} onChange={e => setForm({...form, date_end: e.target.value})} /></div>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {trip.destination && (
              <div className="flex items-center gap-2 text-[#6b6760]">
                <MapPin size={15} className="text-[#e8572a]" />
                <span>{trip.destination}</span>
              </div>
            )}
            {(trip.date_start || trip.date_end) && (
              <div className="flex items-center gap-2 text-[#6b6760]">
                <Calendar size={15} className="text-[#0f7b6c]" />
                <span>
                  {trip.date_start && new Date(trip.date_start).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
                  {trip.date_start && trip.date_end && ' → '}
                  {trip.date_end && new Date(trip.date_end).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </span>
              </div>
            )}
            {trip.locked_destination && (
              <div className="bg-[#e8f5f2] rounded-xl p-3 flex items-center gap-2">
                <Check size={15} className="text-[#0f7b6c]" />
                <span className="text-[#0f7b6c] font-semibold text-sm">Destination locked: {trip.locked_destination}</span>
              </div>
            )}
            {!trip.destination && !trip.date_start && !trip.locked_destination && (
              <p className="text-[#6b6760] text-sm italic">No details yet — add dates and a destination to get started</p>
            )}
          </div>
        )}
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: 'Check availability', desc: 'Find dates that work for everyone', color: 'bg-[#e8f5f2]', accent: 'text-[#0f7b6c]' },
          { label: 'Vote on destination', desc: 'Rank your favorite spots', color: 'bg-[#fdf1ec]', accent: 'text-[#e8572a]' },
          { label: 'Plan activities', desc: 'Build your itinerary together', color: 'bg-[#fdf6e8]', accent: 'text-[#c9973a]' },
          { label: 'Split expenses', desc: 'Track who owes what', color: 'bg-stone-100', accent: 'text-stone-600' },
        ].map(item => (
          <div key={item.label} className={`card p-4 ${item.color} border-0`}>
            <p className={`text-sm font-semibold ${item.accent}`}>{item.label}</p>
            <p className="text-xs text-[#6b6760] mt-0.5">{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
