'use client'
import { useState, useEffect } from 'react'
import { Check, ChevronLeft, ChevronRight, Save } from 'lucide-react'

function getAvatarColor(name: string) {
  const colors = ['bg-[#e8572a]','bg-[#0f7b6c]','bg-[#c9973a]','bg-purple-500','bg-pink-500','bg-blue-500']
  let hash = 0; for (const c of name) hash += c.charCodeAt(0)
  return colors[hash % colors.length]
}

const DAYS = ['Su','Mo','Tu','We','Th','Fr','Sa']
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']

export default function AvailabilityTab({ trip, user, profile, tripId, supabase }: any) {
  const [allAvailability, setAllAvailability] = useState<any[]>([])
  const [myDates, setMyDates] = useState<Set<string>>(new Set())
  const [viewDate, setViewDate] = useState(new Date())
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('availability').select('*, profiles(name)').eq('trip_id', tripId)
      setAllAvailability(data || [])
      const mine = data?.find((r: any) => r.user_id === user.id)
      if (mine) setMyDates(new Set(mine.dates))
    }
    load()
    const sub = supabase.channel(`avail:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'availability', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId, user.id])

  const toggleDate = (dateStr: string) => {
    const next = new Set(myDates)
    next.has(dateStr) ? next.delete(dateStr) : next.add(dateStr)
    setMyDates(next)
  }

  const saveAvailability = async () => {
    setSaving(true)
    const dates = Array.from(myDates)
    await supabase.from('availability').upsert({
      trip_id: tripId, user_id: user.id,
      user_name: profile?.name || 'Unknown',
      dates, updated_at: new Date().toISOString()
    }, { onConflict: 'trip_id,user_id' })
    setSaving(false); setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  // Build calendar grid
  const year = viewDate.getFullYear()
  const month = viewDate.getMonth()
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const cells: (string | null)[] = Array(firstDay).fill(null)
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push(`${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`)
  }
  while (cells.length % 7 !== 0) cells.push(null)

  // Count who's available per date
  const countForDate = (dateStr: string) => allAvailability.filter(a => a.dates?.includes(dateStr)).length
  const maxCount = allAvailability.length || 1

  const getHeatColor = (count: number) => {
    if (count === 0) return ''
    const ratio = count / maxCount
    if (ratio >= 1) return 'bg-[#0f7b6c] text-white'
    if (ratio >= 0.7) return 'bg-[#0f7b6c]/60 text-white'
    if (ratio >= 0.4) return 'bg-[#0f7b6c]/30 text-[#0f7b6c]'
    return 'bg-[#0f7b6c]/15 text-[#0f7b6c]'
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Legend */}
      <div className="card p-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="font-semibold text-sm text-[#1a1814]">Group availability</p>
          <p className="text-xs text-[#6b6760]">Select your available dates, then save</p>
        </div>
        <div className="flex items-center gap-3 text-xs text-[#6b6760]">
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-[#0f7b6c]/20 inline-block" />Some</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-[#0f7b6c]/60 inline-block" />Most</span>
          <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-[#0f7b6c] inline-block" />Everyone</span>
        </div>
      </div>

      {/* Calendar */}
      <div className="card p-5">
        {/* Month nav */}
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setViewDate(new Date(year, month-1))} className="btn-ghost p-2"><ChevronLeft size={16} /></button>
          <h3 className="font-display text-lg font-700">{MONTHS[month]} {year}</h3>
          <button onClick={() => setViewDate(new Date(year, month+1))} className="btn-ghost p-2"><ChevronRight size={16} /></button>
        </div>

        {/* Day headers */}
        <div className="grid grid-cols-7 mb-2">
          {DAYS.map(d => <div key={d} className="text-center text-xs font-semibold text-[#6b6760] py-1">{d}</div>)}
        </div>

        {/* Cells */}
        <div className="grid grid-cols-7 gap-1">
          {cells.map((dateStr, i) => {
            if (!dateStr) return <div key={i} />
            const count = countForDate(dateStr)
            const isSelected = myDates.has(dateStr)
            const isPast = new Date(dateStr) < new Date(new Date().toDateString())
            return (
              <button
                key={dateStr}
                onClick={() => !isPast && toggleDate(dateStr)}
                disabled={isPast}
                className={`
                  aspect-square flex flex-col items-center justify-center rounded-lg text-sm font-medium
                  transition-all relative
                  ${isPast ? 'text-stone-300 cursor-not-allowed' : 'hover:scale-105 cursor-pointer'}
                  ${isSelected ? 'ring-2 ring-[#e8572a] ring-offset-1' : ''}
                  ${count > 0 && !isPast ? getHeatColor(count) : isPast ? '' : 'hover:bg-stone-100'}
                `}
              >
                <span>{parseInt(dateStr.split('-')[2])}</span>
                {count > 0 && <span className="text-[9px] leading-none opacity-70">{count}</span>}
              </button>
            )
          })}
        </div>
      </div>

      {/* Save button */}
      <button onClick={saveAvailability} disabled={saving} className={`w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${saved ? 'bg-[#0f7b6c] text-white' : 'btn-primary'}`}>
        {saved ? <><Check size={16} /> Saved!</> : saving ? 'Saving...' : <><Save size={16} /> Save my availability</>}
      </button>

      {/* Who's submitted */}
      {allAvailability.length > 0 && (
        <div className="card p-4">
          <p className="text-sm font-semibold text-[#1a1814] mb-3">Submitted availability ({allAvailability.length})</p>
          <div className="flex flex-wrap gap-2">
            {allAvailability.map((a: any) => (
              <span key={a.user_id} className={`avatar w-8 h-8 text-xs ${getAvatarColor(a.profiles?.name || 'U')}`}>
                {(a.profiles?.name || 'U')[0].toUpperCase()}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
