'use client'
import { useState, useEffect } from 'react'
import { Plus, Lock, Unlock, Trophy, ExternalLink, X, Lightbulb, ChevronUp, ChevronDown } from 'lucide-react'

export default function DestinationsTab({ trip, user, profile, tripId, canEdit, supabase, onRefresh }: any) {
  const [destinations, setDestinations] = useState<any[]>([])
  const [showAdd, setShowAdd] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('destinations').select('*').eq('trip_id', tripId).order('created_at')
      setDestinations(data || [])
    }
    load()
    const sub = supabase.channel(`dest:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'destinations', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId])

  // Ranked choice scoring
  const getRankedDestinations = () => {
    return destinations.map(d => {
      const votes: Record<string, number> = d.votes || {}
      let score = 0
      const totalVoters = Object.keys(votes).length
      Object.values(votes).forEach((rank: any) => {
        score += Math.max(0, (destinations.length + 1) - rank)
      })
      return { ...d, score, voterCount: totalVoters }
    }).sort((a, b) => b.score - a.score)
  }

  const ranked = getRankedDestinations()

  const myRankForDest = (destId: string) => {
    const d = destinations.find(d => d.id === destId)
    return d?.votes?.[user.id] || null
  }

  const setRank = async (destId: string, rank: number | null) => {
    const dest = destinations.find(d => d.id === destId)
    const votes = { ...(dest?.votes || {}) }
    if (rank === null) delete votes[user.id]
    else votes[user.id] = rank
    await supabase.from('destinations').update({ votes }).eq('id', destId)
  }

  const lockDestination = async (destId: string, location: string) => {
    const isLocked = destinations.find(d => d.id === destId)?.locked
    await supabase.from('destinations').update({ locked: !isLocked }).eq('id', destId)
    await supabase.from('trips').update({ locked_destination: isLocked ? null : location }).eq('id', tripId)
    onRefresh()
  }

  const myRanks = destinations.reduce((acc: Record<string, number>, d) => {
    const r = myRankForDest(d.id)
    if (r) acc[d.id] = r
    return acc
  }, {})
  const ranksUsed = new Set(Object.values(myRanks))

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-700">Vote on destinations</h2>
          <p className="text-sm text-[#6b6760]">Rank your favorites — points are tallied automatically</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary flex items-center gap-2 text-sm">
          <Plus size={15} /> Suggest
        </button>
      </div>

      {destinations.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-4xl mb-3">🌍</p>
          <h3 className="font-display text-lg font-700 mb-1">No destinations yet</h3>
          <p className="text-sm text-[#6b6760] mb-4">Be the first to suggest somewhere</p>
          <button onClick={() => setShowAdd(true)} className="btn-primary text-sm">Suggest a destination</button>
        </div>
      ) : (
        <div className="space-y-3">
          {ranked.map((dest, idx) => {
            const myRank = myRankForDest(dest.id)
            return (
              <div key={dest.id} className={`card p-5 transition-all ${dest.locked ? 'ring-2 ring-[#0f7b6c]' : ''}`}>
                <div className="flex items-start gap-4">
                  {/* Rank badge */}
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                    idx === 0 && dest.score > 0 ? 'bg-[#fdf6e8] text-[#c9973a]' : 'bg-stone-100 text-[#6b6760]'
                  }`}>
                    {idx === 0 && dest.score > 0 ? <Trophy size={16} /> : `#${idx+1}`}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="font-display text-lg font-700">{dest.location}</h3>
                      {dest.locked && <span className="badge-teal">Locked in ✓</span>}
                      {dest.score > 0 && <span className="badge-gold">{dest.score} pts · {dest.voterCount} vote{dest.voterCount !== 1 ? 's' : ''}</span>}
                    </div>
                    {dest.description && <p className="text-sm text-[#6b6760] mb-2">{dest.description}</p>}
                    {dest.ideas?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-2">
                        {dest.ideas.map((idea: string, i: number) => (
                          <span key={i} className="badge-gray text-xs flex items-center gap-1">
                            <Lightbulb size={10} />{idea}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="flex flex-wrap items-center gap-3 text-xs text-[#6b6760]">
                      {dest.estimated_cost && <span>~{dest.estimated_cost}</span>}
                      {dest.best_time && <span>Best: {dest.best_time}</span>}
                      <span>by {dest.suggested_by_name}</span>
                      {dest.link && <a href={dest.link} target="_blank" rel="noreferrer" className="text-[#e8572a] flex items-center gap-1"><ExternalLink size={11} />Learn more</a>}
                    </div>
                  </div>

                  {/* Vote controls */}
                  <div className="flex flex-col items-center gap-1 shrink-0">
                    {!dest.locked && (
                      <>
                        <p className="text-xs text-[#6b6760] mb-1">{myRank ? `#${myRank}` : 'Rank'}</p>
                        <button
                          onClick={() => setRank(dest.id, myRank ? null : (destinations.length - ranksUsed.size))}
                          className={`text-xs px-3 py-1.5 rounded-lg font-semibold transition-all ${myRank ? 'bg-[#e8572a] text-white' : 'bg-stone-100 text-[#6b6760] hover:bg-stone-200'}`}
                        >
                          {myRank ? 'Ranked' : 'Rank it'}
                        </button>
                        {myRank && (
                          <div className="flex gap-1 mt-1">
                            {[1,2,3,4,5].filter(r => r <= destinations.length).map(r => (
                              <button key={r} onClick={() => setRank(dest.id, r)}
                                className={`w-7 h-7 text-xs rounded-lg font-bold transition-all ${myRank === r ? 'bg-[#e8572a] text-white' : 'bg-stone-100 hover:bg-stone-200 text-[#6b6760]'}`}>
                                {r}
                              </button>
                            ))}
                          </div>
                        )}
                      </>
                    )}
                    {canEdit && (
                      <button onClick={() => lockDestination(dest.id, dest.location)}
                        className={`text-xs px-3 py-1.5 rounded-lg font-semibold mt-1 transition-all flex items-center gap-1 ${dest.locked ? 'bg-[#0f7b6c] text-white' : 'border border-stone-200 text-[#6b6760] hover:bg-stone-100'}`}>
                        {dest.locked ? <><Lock size={10} />Locked</> : <><Unlock size={10} />Lock in</>}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {showAdd && <AddDestinationModal tripId={tripId} user={user} profile={profile} supabase={supabase} onClose={() => setShowAdd(false)} />}
    </div>
  )
}

function AddDestinationModal({ tripId, user, profile, supabase, onClose }: any) {
  const [form, setForm] = useState({ location: '', description: '', ideas: [''], link: '', estimated_cost: '', best_time: '' })
  const [loading, setLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true)
    await supabase.from('destinations').insert({
      trip_id: tripId, suggested_by: user.id,
      suggested_by_name: profile?.name || 'Someone',
      location: form.location, description: form.description,
      ideas: form.ideas.filter(i => i.trim()),
      link: form.link || null, estimated_cost: form.estimated_cost || null,
      best_time: form.best_time || null, votes: {}
    })
    setLoading(false); onClose()
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel p-6 sm:p-8" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-700">Suggest a destination</h2>
          <button onClick={onClose} className="btn-ghost p-2"><X size={16} /></button>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Location *</label><input className="input" placeholder="Tokyo, Japan" value={form.location} onChange={e => setForm({...form, location: e.target.value})} required /></div>
          <div><label className="label">Why this place? *</label><textarea className="input min-h-[80px]" placeholder="What makes it special?" value={form.description} onChange={e => setForm({...form, description: e.target.value})} required /></div>
          <div>
            <label className="label">Ideas & highlights</label>
            {form.ideas.map((idea, i) => (
              <div key={i} className="flex gap-2 mb-2">
                <input className="input flex-1" placeholder="e.g., Visit temples, Try ramen" value={idea} onChange={e => { const a=[...form.ideas]; a[i]=e.target.value; setForm({...form, ideas: a}) }} />
                {form.ideas.length > 1 && <button type="button" onClick={() => setForm({...form, ideas: form.ideas.filter((_,j) => j !== i)})} className="btn-ghost p-2 text-red-400"><X size={14} /></button>}
              </div>
            ))}
            <button type="button" onClick={() => setForm({...form, ideas: [...form.ideas, '']})} className="text-sm text-[#e8572a] font-semibold flex items-center gap-1"><Plus size={14} />Add idea</button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Est. cost</label><input className="input" placeholder="$1500/person" value={form.estimated_cost} onChange={e => setForm({...form, estimated_cost: e.target.value})} /></div>
            <div><label className="label">Best time</label><input className="input" placeholder="Spring / Fall" value={form.best_time} onChange={e => setForm({...form, best_time: e.target.value})} /></div>
          </div>
          <div><label className="label">Link (optional)</label><input className="input" type="url" placeholder="https://..." value={form.link} onChange={e => setForm({...form, link: e.target.value})} /></div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1">{loading ? 'Adding...' : 'Add destination'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
