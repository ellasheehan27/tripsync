'use client'
import { useState, useEffect } from 'react'
import { UserPlus, Crown, Shield, User, Trash2, Mail, Copy, Check } from 'lucide-react'

function getAvatarColor(name: string) {
  const colors = ['bg-[#e8572a]','bg-[#0f7b6c]','bg-[#c9973a]','bg-purple-500','bg-pink-500','bg-blue-500']
  let hash = 0
  for (const c of name) hash += c.charCodeAt(0)
  return colors[hash % colors.length]
}

export default function MembersTab({ trip, user, tripId, canEdit, supabase, onRefresh }: any) {
  const [members, setMembers] = useState<any[]>([])
  const [showInvite, setShowInvite] = useState(false)
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviting, setInviting] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('trip_members')
        .select('*, profiles(name, email, avatar_url)')
        .eq('trip_id', tripId)
      setMembers(data || [])
    }
    load()

    const sub = supabase.channel(`members:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trip_members', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId])

  const copyLink = () => {
    navigator.clipboard.writeText(`${window.location.origin}/join/${tripId}`)
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault()
    setInviting(true)
    // Look up user by email
    const { data: inviteProfile } = await supabase.from('profiles').select('id, name, email').eq('email', inviteEmail).single()
    if (inviteProfile) {
      await supabase.from('trip_members').insert({ trip_id: tripId, user_id: inviteProfile.id, role: 'member' })
      setInviteEmail(''); setShowInvite(false)
    } else {
      alert(`No TripSync account found for ${inviteEmail}. Share the invite link instead!`)
    }
    setInviting(false)
  }

  const updateRole = async (userId: string, role: string) => {
    await supabase.from('trip_members').update({ role }).eq('trip_id', tripId).eq('user_id', userId)
  }

  const removeMember = async (userId: string) => {
    if (!confirm('Remove this member from the trip?')) return
    await supabase.from('trip_members').delete().eq('trip_id', tripId).eq('user_id', userId)
  }

  const roleIcon = (role: string) => {
    if (role === 'host') return <Crown size={12} className="text-[#c9973a]" />
    if (role === 'co-host') return <Shield size={12} className="text-[#0f7b6c]" />
    return <User size={12} className="text-stone-400" />
  }

  return (
    <div className="max-w-xl mx-auto space-y-4">
      {/* Invite bar */}
      <div className="card p-4 flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-[#1a1814]">Invite people</p>
          <p className="text-xs text-[#6b6760]">Share a link or add by email</p>
        </div>
        <div className="flex gap-2">
          <button onClick={copyLink} className="btn-secondary text-sm flex items-center gap-1.5 py-2">
            {copied ? <Check size={14} className="text-[#0f7b6c]" /> : <Copy size={14} />}
            {copied ? 'Copied!' : 'Copy link'}
          </button>
          <button onClick={() => setShowInvite(!showInvite)} className="btn-primary text-sm flex items-center gap-1.5 py-2">
            <Mail size={14} /> Email
          </button>
        </div>
      </div>

      {showInvite && (
        <div className="card p-4">
          <form onSubmit={handleInvite} className="flex gap-2">
            <input className="input flex-1" type="email" placeholder="friend@email.com" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} required />
            <button type="submit" disabled={inviting} className="btn-primary py-2 px-4 text-sm">
              {inviting ? '...' : 'Add'}
            </button>
          </form>
          <p className="text-xs text-[#6b6760] mt-2">They must already have a TripSync account. Otherwise, share the link above.</p>
        </div>
      )}

      {/* Member list */}
      <div className="card divide-y divide-stone-100">
        {members.map(m => {
          const name = m.profiles?.name || 'Unknown'
          const email = m.profiles?.email || ''
          const isMe = m.user_id === user?.id
          const isHost = m.role === 'host'
          return (
            <div key={m.user_id} className="flex items-center gap-3 p-4">
              <div className={`avatar w-10 h-10 text-sm ${getAvatarColor(name)}`}>{name[0]?.toUpperCase()}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-sm text-[#1a1814] truncate">{name}</span>
                  {isMe && <span className="badge-gray badge text-xs">you</span>}
                  {roleIcon(m.role)}
                </div>
                <p className="text-xs text-[#6b6760] truncate">{email}</p>
              </div>
              {canEdit && !isHost && (
                <div className="flex items-center gap-2 shrink-0">
                  <select
                    value={m.role}
                    onChange={e => updateRole(m.user_id, e.target.value)}
                    className="text-xs border border-stone-200 rounded-lg px-2 py-1.5 bg-white text-[#1a1814]"
                  >
                    <option value="member">Member</option>
                    <option value="co-host">Co-host</option>
                  </select>
                  <button onClick={() => removeMember(m.user_id)} className="p-1.5 text-stone-400 hover:text-red-500 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
