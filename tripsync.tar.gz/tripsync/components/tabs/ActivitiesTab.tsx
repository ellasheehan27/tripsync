'use client'
import { useState, useEffect } from 'react'
import { Plus, ThumbsUp, ThumbsDown, Lock, Unlock, Trash2, X, Tag, DollarSign, ExternalLink } from 'lucide-react'

const CATEGORIES = ['Food & Drink','Outdoor','Culture','Nightlife','Shopping','Adventure','Relaxation','Other']
const CAT_COLORS: Record<string, string> = {
  'Food & Drink': 'badge-accent', 'Outdoor': 'badge-teal', 'Culture': 'badge-gold',
  'Nightlife': 'bg-purple-100 text-purple-700 badge', 'Shopping': 'badge-gray',
  'Adventure': 'bg-orange-100 text-orange-700 badge', 'Relaxation': 'bg-blue-100 text-blue-700 badge', 'Other': 'badge-gray'
}

export default function ActivitiesTab({ trip, user, profile, tripId, canEdit, supabase }: any) {
  const [activities, setActivities] = useState<any[]>([])
  const [showAdd, setShowAdd] = useState(false)
  const [filter, setFilter] = useState<string>('All')

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('activities').select('*').eq('trip_id', tripId).order('created_at')
      setActivities(data || [])
    }
    load()
    const sub = supabase.channel(`act:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'activities', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId])

  const vote = async (actId: string, type: 'up' | 'down') => {
    const act = activities.find(a => a.id === actId)
    const votes = { ...(act?.votes || {}) }
    if (votes[user.id] === type) delete votes[user.id]
    else votes[user.id] = type
    await supabase.from('activities').update({ votes }).eq('id', actId)
  }

  const toggleLock = async (actId: string) => {
    const act = activities.find(a => a.id === actId)
    await supabase.from('activities').update({ locked: !act?.locked }).eq('id', actId)
  }

  const deleteActivity = async (actId: string) => {
    if (!confirm('Delete this activity?')) return
    await supabase.from('activities').delete().eq('id', actId)
  }

  const getScore = (act: any) => {
    const votes = act.votes || {}
    return Object.values(votes).filter((v: any) => v === 'up').length -
           Object.values(votes).filter((v: any) => v === 'down').length
  }

  const sorted = [...activities]
    .filter(a => filter === 'All' || a.category === filter)
    .sort((a, b) => {
      if (a.locked && !b.locked) return -1
      if (!a.locked && b.locked) return 1
      return getScore(b) - getScore(a)
    })

  const categories = ['All', ...CATEGORIES.filter(c => activities.some(a => a.category === c))]

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-700">Activities</h2>
          <p className="text-sm text-[#6b6760]">Suggest and vote on what to do</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary flex items-center gap-2 text-sm"><Plus size={15} />Add</button>
      </div>

      {/* Category filter */}
      {categories.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map(c => (
            <button key={c} onClick={() => setFilter(c)}
              className={`shrink-0 text-xs px-3 py-1.5 rounded-full font-semibold transition-all ${filter === c ? 'bg-[#e8572a] text-white' : 'bg-white border border-stone-200 text-[#6b6760] hover:bg-stone-50'}`}>
              {c}
            </button>
          ))}
        </div>
      )}

      {sorted.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-4xl mb-3">🎯</p>
          <h3 className="font-display text-lg font-700 mb-1">No activities yet</h3>
          <p className="text-sm text-[#6b6760] mb-4">Start building your wishlist</p>
          <button onClick={() => setShowAdd(true)} className="btn-primary text-sm">Add first activity</button>
        </div>
      ) : (
        <div className="space-y-3">
          {sorted.map(act => {
            const score = getScore(act)
            const myVote = act.votes?.[user.id]
            const upCount = Object.values(act.votes || {}).filter((v: any) => v === 'up').length
            const downCount = Object.values(act.votes || {}).filter((v: any) => v === 'down').length
            return (
              <div key={act.id} className={`card p-4 transition-all ${act.locked ? 'ring-2 ring-[#0f7b6c]' : ''}`}>
                <div className="flex items-start gap-3">
                  {/* Vote buttons */}
                  <div className="flex flex-col items-center gap-1 shrink-0 pt-0.5">
                    <button onClick={() => vote(act.id, 'up')} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${myVote === 'up' ? 'bg-[#0f7b6c] text-white' : 'bg-stone-100 text-[#6b6760] hover:bg-stone-200'}`}><ThumbsUp size={14} /></button>
                    <span className={`text-sm font-bold ${score > 0 ? 'text-[#0f7b6c]' : score < 0 ? 'text-red-500' : 'text-[#6b6760]'}`}>{score > 0 ? '+' : ''}{score}</span>
                    <button onClick={() => vote(act.id, 'down')} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${myVote === 'down' ? 'bg-red-500 text-white' : 'bg-stone-100 text-[#6b6760] hover:bg-stone-200'}`}><ThumbsDown size={14} /></button>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="font-semibold text-[#1a1814]">{act.title}</h3>
                      {act.locked && <span className="badge-teal text-xs">✓ Locked</span>}
                      {act.category && <span className={CAT_COLORS[act.category] || 'badge-gray'}>{act.category}</span>}
                    </div>
                    {act.description && <p className="text-sm text-[#6b6760] mb-2">{act.description}</p>}
                    <div className="flex flex-wrap items-center gap-3 text-xs text-[#6b6760]">
                      {act.cost && <span className="flex items-center gap-1"><DollarSign size={10} />{act.cost}</span>}
                      <span>by {act.suggested_by_name}</span>
                      <span>{upCount} 👍 · {downCount} 👎</span>
                      {act.link && <a href={act.link} target="_blank" rel="noreferrer" className="text-[#e8572a] flex items-center gap-1"><ExternalLink size={10} />Link</a>}
                    </div>
                  </div>

                  {canEdit && (
                    <div className="flex flex-col gap-1 shrink-0">
                      <button onClick={() => toggleLock(act.id)} className={`p-1.5 rounded-lg transition-all ${act.locked ? 'text-[#0f7b6c] bg-[#e8f5f2]' : 'text-stone-400 hover:text-[#0f7b6c] hover:bg-[#e8f5f2]'}`}>
                        {act.locked ? <Lock size={13} /> : <Unlock size={13} />}
                      </button>
                      <button onClick={() => deleteActivity(act.id)} className="p-1.5 rounded-lg text-stone-400 hover:text-red-500 hover:bg-red-50 transition-all"><Trash2 size={13} /></button>
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {showAdd && <AddActivityModal tripId={tripId} user={user} profile={profile} supabase={supabase} onClose={() => setShowAdd(false)} />}
    </div>
  )
}

function AddActivityModal({ tripId, user, profile, supabase, onClose }: any) {
  const [form, setForm] = useState({ title: '', description: '', category: '', cost: '', link: '' })
  const [loading, setLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true)
    await supabase.from('activities').insert({
      trip_id: tripId, suggested_by: user.id,
      suggested_by_name: profile?.name || 'Someone',
      title: form.title, description: form.description || null,
      category: form.category || null, cost: form.cost || null,
      link: form.link || null, votes: {}, locked: false
    })
    setLoading(false); onClose()
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel p-6 sm:p-8" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-700">Add activity</h2>
          <button onClick={onClose} className="btn-ghost p-2"><X size={16} /></button>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Activity name *</label><input className="input" placeholder="Hiking at Cinque Terre" value={form.title} onChange={e => setForm({...form, title: e.target.value})} required /></div>
          <div><label className="label">Description</label><textarea className="input min-h-[70px]" placeholder="Details, tips, why you'd recommend it..." value={form.description} onChange={e => setForm({...form, description: e.target.value})} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Category</label>
              <select className="input" value={form.category} onChange={e => setForm({...form, category: e.target.value})}>
                <option value="">Select...</option>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div><label className="label">Approx. cost</label><input className="input" placeholder="$30/person" value={form.cost} onChange={e => setForm({...form, cost: e.target.value})} /></div>
          </div>
          <div><label className="label">Link (optional)</label><input className="input" type="url" placeholder="https://..." value={form.link} onChange={e => setForm({...form, link: e.target.value})} /></div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1">{loading ? 'Adding...' : 'Add activity'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
