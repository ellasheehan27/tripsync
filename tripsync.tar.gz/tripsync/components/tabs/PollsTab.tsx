'use client'
import { useState, useEffect } from 'react'
import { Plus, X, Check, BarChart2, Lock, Unlock } from 'lucide-react'

function getAvatarColor(name: string) {
  const colors = ['bg-[#e8572a]','bg-[#0f7b6c]','bg-[#c9973a]','bg-purple-500','bg-pink-500','bg-blue-500']
  let hash = 0; for (const c of name) hash += c.charCodeAt(0)
  return colors[hash % colors.length]
}

export default function PollsTab({ trip, user, profile, tripId, canEdit, supabase }: any) {
  const [polls, setPolls] = useState<any[]>([])
  const [showCreate, setShowCreate] = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from('polls').select('*').eq('trip_id', tripId).order('created_at', { ascending: false })
      setPolls(data || [])
    }
    load()
    const sub = supabase.channel(`polls:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'polls', filter: `trip_id=eq.${tripId}` }, load)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [supabase, tripId])

  const castVote = async (pollId: string, optionIdx: number) => {
    const poll = polls.find(p => p.id === pollId)
    if (!poll?.is_open) return
    const votes = { ...(poll.votes || {}) }
    votes[user.id] = optionIdx
    await supabase.from('polls').update({ votes }).eq('id', pollId)
  }

  const toggleOpen = async (pollId: string, isOpen: boolean) => {
    await supabase.from('polls').update({ is_open: !isOpen }).eq('id', pollId)
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-700">Polls</h2>
          <p className="text-sm text-[#6b6760]">Make group decisions fast</p>
        </div>
        {canEdit && (
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2 text-sm"><Plus size={15} />New poll</button>
        )}
      </div>

      {polls.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-4xl mb-3">🗳️</p>
          <h3 className="font-display text-lg font-700 mb-1">No polls yet</h3>
          <p className="text-sm text-[#6b6760] mb-4">
            {canEdit ? 'Create a poll to get the group\'s input on anything' : 'The host will create polls here'}
          </p>
          {canEdit && <button onClick={() => setShowCreate(true)} className="btn-primary text-sm">Create first poll</button>}
        </div>
      ) : (
        <div className="space-y-4">
          {polls.map(poll => {
            const options: string[] = poll.options || []
            const votes: Record<string, number> = poll.votes || {}
            const totalVotes = Object.keys(votes).length
            const myVote = votes[user.id]
            const voteCounts = options.map((_: any, i: number) => Object.values(votes).filter(v => v === i).length)
            const maxVotes = Math.max(...voteCounts, 1)
            const winnerIdx = voteCounts.indexOf(Math.max(...voteCounts))

            return (
              <div key={poll.id} className="card p-5">
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`w-2 h-2 rounded-full ${poll.is_open ? 'bg-emerald-500 animate-pulse' : 'bg-stone-400'}`} />
                      <span className="text-xs font-semibold text-[#6b6760]">{poll.is_open ? 'Open' : 'Closed'} · {totalVotes} vote{totalVotes !== 1 ? 's' : ''}</span>
                    </div>
                    <h3 className="font-display text-lg font-700 text-[#1a1814]">{poll.question}</h3>
                  </div>
                  {canEdit && (
                    <button onClick={() => toggleOpen(poll.id, poll.is_open)}
                      className={`shrink-0 flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-semibold transition-all ${poll.is_open ? 'bg-stone-100 text-[#6b6760] hover:bg-stone-200' : 'bg-[#e8f5f2] text-[#0f7b6c]'}`}>
                      {poll.is_open ? <><Lock size={11} />Close</> : <><Unlock size={11} />Reopen</>}
                    </button>
                  )}
                </div>

                <div className="space-y-2">
                  {options.map((opt: string, i: number) => {
                    const count = voteCounts[i]
                    const pct = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0
                    const isWinner = !poll.is_open && i === winnerIdx && count > 0
                    const isMyVote = myVote === i

                    return (
                      <button key={i} onClick={() => poll.is_open && castVote(poll.id, i)} disabled={!poll.is_open}
                        className={`w-full text-left rounded-xl p-3 transition-all relative overflow-hidden border ${
                          isWinner ? 'border-[#0f7b6c] bg-[#e8f5f2]' :
                          isMyVote ? 'border-[#e8572a] bg-[#fdf1ec]' :
                          poll.is_open ? 'border-stone-200 hover:border-stone-300 hover:bg-stone-50' : 'border-stone-200'
                        }`}>
                        {/* Progress bar */}
                        {totalVotes > 0 && (
                          <div className={`absolute inset-y-0 left-0 transition-all duration-500 ${isWinner ? 'bg-[#0f7b6c]/10' : 'bg-stone-100'}`}
                            style={{ width: `${pct}%` }} />
                        )}
                        <div className="relative flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {isMyVote && <Check size={14} className="text-[#e8572a] shrink-0" />}
                            {isWinner && <BarChart2 size={14} className="text-[#0f7b6c] shrink-0" />}
                            <span className={`text-sm font-semibold ${isWinner ? 'text-[#0f7b6c]' : 'text-[#1a1814]'}`}>{opt}</span>
                          </div>
                          <span className="text-xs font-bold text-[#6b6760] ml-2 shrink-0">{pct}% ({count})</span>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {showCreate && (
        <CreatePollModal tripId={tripId} user={user} profile={profile} supabase={supabase} onClose={() => setShowCreate(false)} />
      )}
    </div>
  )
}

function CreatePollModal({ tripId, user, supabase, onClose }: any) {
  const [question, setQuestion] = useState('')
  const [options, setOptions] = useState(['', ''])
  const [loading, setLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    const cleanOptions = options.filter(o => o.trim())
    if (cleanOptions.length < 2) return alert('Add at least 2 options')
    setLoading(true)
    await supabase.from('polls').insert({
      trip_id: tripId, created_by: user.id,
      question, options: cleanOptions, votes: {}, is_open: true
    })
    setLoading(false); onClose()
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-panel p-6 sm:p-8" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-700">Create a poll</h2>
          <button onClick={onClose} className="btn-ghost p-2"><X size={16} /></button>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Question *</label><input className="input" placeholder="Which hotel should we book?" value={question} onChange={e => setQuestion(e.target.value)} required /></div>
          <div>
            <label className="label">Options</label>
            <div className="space-y-2">
              {options.map((opt, i) => (
                <div key={i} className="flex gap-2">
                  <input className="input flex-1" placeholder={`Option ${i + 1}`} value={opt} onChange={e => { const o = [...options]; o[i] = e.target.value; setOptions(o) }} />
                  {options.length > 2 && (
                    <button type="button" onClick={() => setOptions(options.filter((_, j) => j !== i))} className="btn-ghost p-2 text-red-400"><X size={14} /></button>
                  )}
                </div>
              ))}
            </div>
            <button type="button" onClick={() => setOptions([...options, ''])} className="mt-2 text-sm text-[#e8572a] font-semibold flex items-center gap-1"><Plus size={14} />Add option</button>
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1">{loading ? 'Creating...' : 'Create poll'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
