'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import { Plane, Mail, Lock, User, ArrowRight, Sparkles } from 'lucide-react'

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'signup' | 'magic'>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [magicSent, setMagicSent] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const getRedirect = () => {
    const pending = typeof window !== 'undefined' ? sessionStorage.getItem('pendingJoin') : null
    if (pending) { sessionStorage.removeItem('pendingJoin'); return `/join/${pending}` }
    return '/dashboard'
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false) }
    else router.push(getRedirect())
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError('')
    const { error } = await supabase.auth.signUp({ email, password, options: { data: { name } } })
    if (error) { setError(error.message); setLoading(false) }
    else router.push(getRedirect())
  }

  const handleMagicLink = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError('')
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${window.location.origin}${getRedirect()}` }
    })
    if (error) setError(error.message)
    else setMagicSent(true)
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-[#f7f4ef] flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-[#e8572a]/6" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-[#0f7b6c]/6" />
      </div>

      <div className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#e8572a] mb-4 shadow-lg shadow-[#e8572a]/25">
            <Plane className="text-white" size={28} />
          </div>
          <h1 className="font-display text-3xl font-bold text-[#1a1814]">TripSync</h1>
          <p className="text-[#6b6760] mt-1">Plan group trips, effortlessly</p>
        </div>

        <div className="card p-8">
          <div className="flex gap-1 bg-stone-100 p-1 rounded-xl mb-6">
            {(['login', 'signup', 'magic'] as const).map(m => (
              <button key={m} onClick={() => { setMode(m); setError(''); setMagicSent(false) }}
                className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${mode === m ? 'bg-white text-[#1a1814] shadow-sm' : 'text-[#6b6760] hover:text-[#1a1814]'}`}>
                {m === 'login' ? 'Log in' : m === 'signup' ? 'Sign up' : '✨ Magic link'}
              </button>
            ))}
          </div>

          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl p-3 mb-4">{error}</div>}

          {magicSent ? (
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-[#e8f5f2] rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="text-[#0f7b6c]" size={28} />
              </div>
              <h3 className="font-display text-xl font-bold mb-2">Check your email</h3>
              <p className="text-[#6b6760] text-sm">We sent a magic link to <strong>{email}</strong>. Click it to sign in instantly.</p>
            </div>
          ) : (
            <form onSubmit={mode === 'login' ? handleLogin : mode === 'signup' ? handleSignup : handleMagicLink} className="space-y-4">
              {mode === 'signup' && (
                <div>
                  <label className="label">Your name</label>
                  <div className="relative">
                    <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input className="input pl-10" placeholder="Ella Sheehan" value={name} onChange={e => setName(e.target.value)} required />
                  </div>
                </div>
              )}
              <div>
                <label className="label">Email</label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input className="input pl-10" type="email" placeholder="you@email.com" value={email} onChange={e => setEmail(e.target.value)} required />
                </div>
              </div>
              {mode !== 'magic' && (
                <div>
                  <label className="label">Password</label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input className="input pl-10" type="password" placeholder={mode === 'signup' ? 'At least 6 characters' : '••••••••'} value={password} onChange={e => setPassword(e.target.value)} required minLength={mode === 'signup' ? 6 : undefined} />
                  </div>
                </div>
              )}
              <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2 py-3 mt-2">
                {loading ? 'Please wait...' : mode === 'login' ? 'Log in' : mode === 'signup' ? 'Create account' : 'Send magic link'}
                {!loading && <ArrowRight size={16} />}
              </button>
            </form>
          )}
          {mode === 'magic' && !magicSent && (
            <p className="text-center text-xs text-[#6b6760] mt-4">
              <Sparkles size={12} className="inline mr-1" />No password needed — one-click sign-in
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
