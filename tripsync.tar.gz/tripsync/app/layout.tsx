import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'TripSync — Plan Group Trips Together',
  description: 'The easiest way to plan group trips. Coordinate availability, vote on destinations, split expenses, and keep everyone in sync.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
