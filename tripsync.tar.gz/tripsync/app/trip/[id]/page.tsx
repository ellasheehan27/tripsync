'use client'
import { useState, useEffect, useCallback } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter, useParams } from 'next/navigation'
import {
  ArrowLeft, Users, MapPin, Vote, Calendar, DollarSign,
  ListTodo, Megaphone, BarChart2, Plus, Crown, Copy,
  Check, Loader2, Wifi, Settings
} from 'lucide-react'
import OverviewTab from '@/components/tabs/OverviewTab'
import MembersTab from '@/components/tabs/MembersTab'
import DestinationsTab from '@/components/tabs/DestinationsTab'
import ActivitiesTab from '@/components/tabs/ActivitiesTab'
import AvailabilityTab from '@/components/tabs/AvailabilityTab'
import ExpensesTab from '@/components/tabs/ExpensesTab'
import PollsTab from '@/components/tabs/PollsTab'
import AnnouncementsTab from '@/components/tabs/AnnouncementsTab'

const TABS = [
  { id: 'overview',       label: 'Overview',       icon: MapPin },
  { id: 'availability',   label: 'Availability',   icon: Calendar },
  { id: 'destinations',   label: 'Destinations',   icon: Vote },
  { id: 'activities',     label: 'Activities',     icon: ListTodo },
  { id: 'expenses',       label: 'Expenses',       icon: DollarSign },
  { id: 'polls',          label: 'Polls',          icon: BarChart2 },
  { id: 'announcements',  label: 'Updates',        icon: Megaphone },
  { id: 'members',        label: 'Members',        icon: Users },
]

export default function TripPage() {
  const params = useParams()
  const tripId = params.id as string
  const [trip, setTrip] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [myRole, setMyRole] = useState<string>('member')
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const [liveCount, setLiveCount] = useState(0)
  const router = useRouter()
  const supabase = createClient()

  const loadTrip = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/auth'); return }
    setUser(user)

    const { data: prof } = await supabase.from('profiles').select('*').eq('id', user.id).single()
    setProfile(prof)

    const { data: tripData } = await supabase.from('trips').select('*').eq('id', tripId).single()
    if (!tripData) { router.push('/dashboard'); return }
    setTrip(tripData)

    const { data: myMember } = await supabase
      .from('trip_members').select('role').eq('trip_id', tripId).eq('user_id', user.id).single()
    if (myMember) setMyRole(myMember.role)

    setLoading(false)
  }, [supabase, tripId, router])

  useEffect(() => {
    loadTrip()

    // Real-time subscription for trip changes
    const tripSub = supabase
      .channel(`trip:${tripId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trips', filter: `id=eq.${tripId}` },
        (payload) => { if (payload.new) setTrip(payload.new) })
      .subscribe()

    // Presence: track who's online
    const presenceSub = supabase
      .channel(`presence:${tripId}`)
      .on('presence', { event: 'sync' }, () => {
        const state = presenceSub.presenceState()
        setLiveCount(Object.keys(state).length)
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await presenceSub.track({ userId: supabase.auth.getUser().then(r => r.data.user?.id) })
        }
      })

    return () => {
      supabase.removeChannel(tripSub)
      supabase.removeChannel(presenceSub)
    }
  }, [loadTrip, supabase, tripId])

  const copyInviteLink = () => {
    navigator.clipboard.writeText(`${window.location.origin}/join/${tripId}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const canEdit = myRole === 'host' || myRole === 'co-host'

  if (loading) return (
    <div className="min-h-screen bg-[#f7f4ef] flex items-center justify-center">
      <Loader2 className="animate-spin text-[#e8572a]" size={32} />
    </div>
  )

  const tabProps = { trip, user, profile, tripId, canEdit, onRefresh: loadTrip, supabase }

  return (
    <div className="min-h-screen bg-[#f7f4ef]">
      {/* Trip header */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4">
          <div className="h-14 flex items-center gap-3">
            <button onClick={() => router.push('/dashboard')} className="btn-ghost p-2 -ml-2">
              <ArrowLeft size={18} />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="font-display text-lg font-700 text-[#1a1814] truncate">{trip?.name}</h1>
                {myRole === 'host' && <Crown size={14} className="text-[#c9973a] shrink-0" />}
              </div>
            </div>
            {/* Live indicator */}
            {liveCount > 1 && (
              <div className="hidden sm:flex items-center gap-1.5 badge-teal badge text-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                {liveCount} online
              </div>
            )}
            <button onClick={copyInviteLink} className="btn-secondary text-sm flex items-center gap-1.5 py-2">
              {copied ? <Check size={14} className="text-[#0f7b6c]" /> : <Copy size={14} />}
              <span className="hidden sm:block">{copied ? 'Copied!' : 'Invite'}</span>
            </button>
          </div>

          {/* Tabs — scrollable */}
          <div className="flex gap-1 overflow-x-auto pb-0 no-scrollbar -mx-1 px-1">
            {TABS.map(tab => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`nav-tab mb-0 border-b-2 rounded-none px-3 py-3 text-xs gap-1.5 ${
                    activeTab === tab.id
                      ? 'border-[#e8572a] text-[#e8572a] font-700'
                      : 'border-transparent text-[#6b6760] hover:text-[#1a1814]'
                  }`}
                >
                  <Icon size={13} />
                  {tab.label}
                </button>
              )
            })}
          </div>
        </div>
      </header>

      {/* Tab content */}
      <main className="max-w-6xl mx-auto px-4 py-6 fade-up" key={activeTab}>
        {activeTab === 'overview'      && <OverviewTab {...tabProps} />}
        {activeTab === 'availability'  && <AvailabilityTab {...tabProps} />}
        {activeTab === 'destinations'  && <DestinationsTab {...tabProps} />}
        {activeTab === 'activities'    && <ActivitiesTab {...tabProps} />}
        {activeTab === 'expenses'      && <ExpensesTab {...tabProps} />}
        {activeTab === 'polls'         && <PollsTab {...tabProps} />}
        {activeTab === 'announcements' && <AnnouncementsTab {...tabProps} />}
        {activeTab === 'members'       && <MembersTab {...tabProps} />}
      </main>
    </div>
  )
}
