'use client'
import { useState, useEffect, useCallback } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import { Plus, Plane, Users, MapPin, Calendar, LogOut, Crown, ChevronRight, Loader2 } from 'lucide-react'
import CreateTripModal from '@/components/CreateTripModal'

function getAvatarColor(name: string) {
  const colors = ['bg-[#e8572a]','bg-[#0f7b6c]','bg-[#c9973a]','bg-purple-500','bg-pink-500','bg-blue-500','bg-indigo-500','bg-rose-500']
  let hash = 0
  for (const c of name) hash += c.charCodeAt(0)
  return colors[hash % colors.length]
}

export default function Dashboard() {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [trips, setTrips] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const loadData = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/auth'); return }
    setUser(user)

    const { data: prof } = await supabase.from('profiles').select('*').eq('id', user.id).single()
    setProfile(prof)

    const { data: memberRows } = await supabase
      .from('trip_members').select('trip_id').eq('user_id', user.id)
    const tripIds = (memberRows || []).map((r: any) => r.trip_id)

    if (tripIds.length > 0) {
      const { data: tripsData } = await supabase
        .from('trips').select('*, trip_members(count)').in('id', tripIds).order('created_at', { ascending: false })
      setTrips(tripsData || [])
    }
    setLoading(false)
  }, [supabase, router])

  useEffect(() => { loadData() }, [loadData])

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/auth')
  }

  if (loading) return (
    <div className="min-h-screen bg-[#f7f4ef] flex items-center justify-center">
      <Loader2 className="animate-spin text-[#e8572a]" size={32} />
    </div>
  )

  const displayName = profile?.name || user?.user_metadata?.name || user?.email?.split('@')[0] || 'Traveler'

  return (
    <div className="min-h-screen bg-[#f7f4ef]">
      {/* Top nav */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#e8572a] flex items-center justify-center">
              <Plane size={16} className="text-white" />
            </div>
            <span className="font-display text-lg font-700 text-[#1a1814]">TripSync</span>
          </div>
          <div className="flex items-center gap-3">
            <div className={`avatar w-8 h-8 text-sm ${getAvatarColor(displayName)}`}>
              {displayName[0].toUpperCase()}
            </div>
            <span className="text-sm font-semibold text-[#1a1814] hidden sm:block">{displayName}</span>
            <button onClick={handleLogout} className="btn-ghost text-sm flex items-center gap-1.5 py-1.5">
              <LogOut size={14} />
              <span className="hidden sm:block">Log out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        {/* Hero row */}
        <div className="flex items-start justify-between mb-8 fade-up">
          <div>
            <h1 className="font-display text-3xl sm:text-4xl font-700 text-[#1a1814]">
              Hey {displayName.split(' ')[0]} 👋
            </h1>
            <p className="text-[#6b6760] mt-1">
              {trips.length === 0 ? "Ready to start your first adventure?" : `You have ${trips.length} trip${trips.length === 1 ? '' : 's'} in the works`}
            </p>
          </div>
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2 shrink-0">
            <Plus size={16} />
            <span className="hidden sm:block">New trip</span>
          </button>
        </div>

        {/* Trips grid */}
        {trips.length === 0 ? (
          <div className="card p-16 text-center fade-up">
            <div className="w-20 h-20 rounded-2xl bg-[#fdf1ec] flex items-center justify-center mx-auto mb-5">
              <Plane size={36} className="text-[#e8572a]" />
            </div>
            <h2 className="font-display text-2xl font-700 mb-2">No trips yet</h2>
            <p className="text-[#6b6760] mb-6">Create your first group trip and invite your crew</p>
            <button onClick={() => setShowCreate(true)} className="btn-primary inline-flex items-center gap-2">
              <Plus size={16} /> Plan your first trip
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 stagger">
            {trips.map(trip => (
              <TripCard
                key={trip.id}
                trip={trip}
                isHost={trip.host_id === user?.id}
                onClick={() => router.push(`/trip/${trip.id}`)}
              />
            ))}
            {/* Create new card */}
            <button
              onClick={() => setShowCreate(true)}
              className="card border-2 border-dashed border-stone-300 p-8 flex flex-col items-center justify-center gap-3 text-stone-400 hover:text-[#e8572a] hover:border-[#e8572a]/40 hover:bg-[#fdf1ec]/30 transition-all duration-200 rounded-2xl cursor-pointer"
            >
              <Plus size={28} />
              <span className="text-sm font-semibold">New trip</span>
            </button>
          </div>
        )}
      </main>

      {showCreate && (
        <CreateTripModal
          userId={user?.id}
          onClose={() => setShowCreate(false)}
          onCreated={(id) => { setShowCreate(false); router.push(`/trip/${id}`) }}
        />
      )}
    </div>
  )
}

function TripCard({ trip, isHost, onClick }: { trip: any; isHost: boolean; onClick: () => void }) {
  const memberCount = trip.trip_members?.[0]?.count || 1
  const gradients = [
    'from-[#e8572a] to-[#c9973a]',
    'from-[#0f7b6c] to-[#0d6b5e]',
    'from-indigo-500 to-purple-600',
    'from-pink-500 to-rose-500',
    'from-blue-500 to-cyan-500',
  ]
  let hash = 0
  for (const c of trip.name) hash += c.charCodeAt(0)
  const grad = gradients[hash % gradients.length]

  return (
    <div onClick={onClick} className="card-hover overflow-hidden group">
      {/* Image / placeholder */}
      <div className="relative h-40 overflow-hidden">
        {trip.image_url ? (
          <img src={trip.image_url} alt={trip.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        ) : (
          <div className={`w-full h-full bg-gradient-to-br ${grad} flex items-center justify-center`}>
            <Plane size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        {isHost && (
          <span className="absolute top-3 right-3 badge bg-white/90 text-[#e8572a] backdrop-blur-sm">
            <Crown size={10} className="inline mr-1" />Host
          </span>
        )}
        {trip.locked_destination && (
          <span className="absolute bottom-3 left-3 badge bg-[#0f7b6c]/90 text-white backdrop-blur-sm">
            <MapPin size={10} className="inline mr-1" />{trip.locked_destination}
          </span>
        )}
      </div>

      {/* Info */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-2 mb-3">
          <h3 className="font-display text-lg font-700 text-[#1a1814] leading-tight">{trip.name}</h3>
          <ChevronRight size={18} className="text-stone-400 shrink-0 group-hover:text-[#e8572a] transition-colors" />
        </div>
        {trip.destination && (
          <p className="text-sm text-[#6b6760] mb-3 flex items-center gap-1.5">
            <MapPin size={12} className="text-[#e8572a]" />
            {trip.destination}
          </p>
        )}
        {(trip.date_start || trip.date_end) && (
          <p className="text-xs text-[#6b6760] mb-3 flex items-center gap-1.5">
            <Calendar size={12} />
            {trip.date_start && new Date(trip.date_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            {trip.date_start && trip.date_end && ' → '}
            {trip.date_end && new Date(trip.date_end).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
          </p>
        )}
        <div className="flex items-center gap-1.5 text-sm text-[#6b6760]">
          <Users size={13} className="text-[#0f7b6c]" />
          <span>{memberCount} {memberCount === 1 ? 'member' : 'members'}</span>
        </div>
      </div>
    </div>
  )
}
