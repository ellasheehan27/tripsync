'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase'
import { useRouter, useParams } from 'next/navigation'
import { Plane, Users, MapPin, Calendar, Loader2, Check, LogIn } from 'lucide-react'

export default function JoinPage() {
  const params = useParams()
  const tripId = params.id as string
  const [trip, setTrip] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'joining' | 'joined' | 'already' | 'error'>('loading')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      setUser(user)

      const { data: tripData } = await supabase.from('trips').select('*').eq('id', tripId).single()
      if (!tripData) { setStatus('error'); return }
      setTrip(tripData)

      if (user) {
        const { data: existing } = await supabase
          .from('trip_members').select('user_id').eq('trip_id', tripId).eq('user_id', user.id).single()
        if (existing) { setStatus('already') } else { setStatus('ready') }
      } else {
        setStatus('ready')
      }
    }
    init()
  }, [supabase, tripId])

  const handleJoin = async () => {
    if (!user) {
      // Save intended join and redirect to auth
      sessionStorage.setItem('joinAfterAuth', tripId)
      router.push('/auth')
      return
    }
    setStatus('joining')
    await supabase.from('trip_members').insert({ trip_id: tripId, user_id: user.id, role: 'member' })
    setStatus('joined')
    setTimeout(() => router.push(`/trip/${tripId}`), 1200)
  }

  if (status === 'loading') return (
    <div className="min-h-screen bg-[#f7f4ef] flex items-center justify-center">
      <Loader2 className="animate-spin text-[#e8572a]" size={32} />
    </div>
  )

  if (status === 'error') return (
    <div className="min-h-screen bg-[#f7f4ef] flex items-center justify-center p-4">
      <div className="card p-8 text-center max-w-sm w-full">
        <p className="text-4xl mb-3">😕</p>
        <h2 className="font-display text-xl font-700 mb-2">Trip not found</h2>
        <p className="text-sm text-[#6b6760] mb-4">This invite link may be invalid or expired.</p>
        <button onClick={() => router.push('/dashboard')} className="btn-primary w-full">Go to dashboard</button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[#f7f4ef] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-[#e8572a] mb-3">
            <Plane size={22} className="text-white" />
          </div>
          <p className="text-sm text-[#6b6760] font-semibold">You're invited to join a trip on</p>
          <h1 className="font-display text-2xl font-700 text-[#1a1814]">TripSync</h1>
        </div>

        {/* Trip card */}
        <div className="card p-6 mb-4">
          <h2 className="font-display text-2xl font-700 text-[#1a1814] mb-4">{trip?.name}</h2>
          <div className="space-y-2">
            {trip?.destination && (
              <div className="flex items-center gap-2 text-sm text-[#6b6760]">
                <MapPin size={14} className="text-[#e8572a]" /> {trip.destination}
              </div>
            )}
            {(trip?.date_start || trip?.date_end) && (
              <div className="flex items-center gap-2 text-sm text-[#6b6760]">
                <Calendar size={14} className="text-[#0f7b6c]" />
                {trip.date_start && new Date(trip.date_start).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
                {trip.date_start && trip.date_end && ' → '}
                {trip.date_end && new Date(trip.date_end).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </div>
            )}
          </div>
        </div>

        {status === 'already' ? (
          <div className="space-y-3">
            <div className="card p-4 flex items-center gap-3 bg-[#e8f5f2]">
              <Check size={18} className="text-[#0f7b6c]" />
              <p className="text-sm font-semibold text-[#0f7b6c]">You're already a member of this trip</p>
            </div>
            <button onClick={() => router.push(`/trip/${tripId}`)} className="btn-primary w-full flex items-center justify-center gap-2">
              Open trip <LogIn size={15} />
            </button>
          </div>
        ) : status === 'joined' ? (
          <div className="card p-5 text-center bg-[#e8f5f2]">
            <Check size={28} className="text-[#0f7b6c] mx-auto mb-2" />
            <p className="font-semibold text-[#0f7b6c]">You joined! Redirecting...</p>
          </div>
        ) : (
          <div className="space-y-3">
            <button onClick={handleJoin} disabled={status === 'joining'} className="btn-primary w-full py-3 flex items-center justify-center gap-2 text-base">
              {status === 'joining' ? <Loader2 size={18} className="animate-spin" /> : <Users size={18} />}
              {user ? 'Join this trip' : 'Sign in to join'}
            </button>
            {!user && (
              <p className="text-center text-xs text-[#6b6760]">
                Don&apos;t have an account? You&apos;ll be able to create one on the next page.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
