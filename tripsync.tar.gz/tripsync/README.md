# TripSync

Group trip planning app — availability, destination voting, activities, expenses, polls, and announcements. Built with Next.js 14 + Supabase + Tailwind.

## Setup

1. **Run the SQL** in `supabase_setup.sql` in your Supabase SQL editor
2. **Environment variables** — already set in `.env.local` for your project
3. **Install & run locally:**
   ```bash
   npm install
   npm run dev
   ```
4. **Deploy to Vercel:**
   - Push to GitHub
   - Connect repo in vercel.com
   - Add env vars: `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - Deploy!

## Features
- Auth: email/password + magic link (Supabase Auth)
- Real-time updates across all tabs (Supabase Realtime)
- Availability calendar with group heat map
- Ranked-choice destination voting
- Activity suggestions with upvote/downvote
- Expense tracking with auto settlement calculator
- Polls for group decisions
- Announcements / pinned updates from hosts
- Invite by link or email
- Role system: host / co-host / member

## Stack
- **Next.js 14** (App Router)
- **Supabase** (auth, database, realtime)
- **Tailwind CSS**
- **Lucide React** (icons)
- **DM Sans + Syne** (fonts)
- **Deployed on Vercel**
